import { createClient } from "@supabase/supabase-js";

const url = import.meta.env.VITE_SUPABASE_URL;
const key = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const configured = Boolean(url && key);

// placeholder values keep the UI renderable (shows a setup banner) when .env is missing
export const supabase = createClient(url || "https://placeholder.supabase.co", key || "placeholder-key");

export const inr = (n) => (Number(n) > 0 ? `₹${Number(n)}` : "FREE");
export const when = (iso) =>
  new Date(iso).toLocaleString("en-IN", { day: "numeric", month: "short", hour: "numeric", minute: "2-digit" });
export const isAdult = (dob) => {
  if (!dob) return false;
  const d = new Date(dob);
  const cutoff = new Date();
  cutoff.setFullYear(cutoff.getFullYear() - 18);
  return d <= cutoff;
};
