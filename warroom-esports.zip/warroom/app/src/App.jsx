import { useEffect, useState, useCallback } from "react";
import { Routes, Route, NavLink, Navigate } from "react-router-dom";
import { supabase, configured } from "./supabase.js";
import Auth from "./pages/Auth.jsx";
import Home from "./pages/Home.jsx";
import Tournament from "./pages/Tournament.jsx";
import MyMatches from "./pages/MyMatches.jsx";
import Leaderboard from "./pages/Leaderboard.jsx";
import Profile from "./pages/Profile.jsx";
import Admin from "./pages/Admin.jsx";

export default function App() {
  const [session, setSession] = useState(undefined); // undefined = loading
  const [profile, setProfile] = useState(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setSession(data.session ?? null));
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => setSession(s ?? null));
    return () => sub.subscription.unsubscribe();
  }, []);

  const loadProfile = useCallback(async () => {
    if (!session) return setProfile(null);
    const { data } = await supabase.from("profiles").select("*").eq("id", session.user.id).single();
    setProfile(data);
  }, [session]);
  useEffect(() => { loadProfile(); }, [loadProfile]);

  if (session === undefined) return <div className="shell muted">Loading…</div>;
  if (!session) return <Auth />;

  const isAdmin = profile?.role === "admin" || profile?.role === "owner";

  return (
    <>
      <div className="shell">
        {!configured && (
          <div className="banner">Supabase is not configured yet. Copy <b>.env.example</b> to <b>.env</b> and add your project URL and key.</div>
        )}
        <div className="top">
          <div className="brand">WAR<span>ROOM</span> <span style={{ fontSize: 11, color: "#9a9aa8" }}>ESPORTS</span></div>
          {profile && <span className="pill">{profile.username}</span>}
        </div>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/t/:id" element={<Tournament profile={profile} />} />
          <Route path="/my" element={<MyMatches />} />
          <Route path="/top" element={<Leaderboard />} />
          <Route path="/me" element={<Profile profile={profile} reload={loadProfile} isAdmin={isAdmin} />} />
          <Route path="/admin" element={isAdmin ? <Admin profile={profile} /> : <Navigate to="/" />} />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </div>
      <nav className="nav">
        <div className="nav-in">
          <NavLink to="/" end className={({ isActive }) => (isActive ? "on" : "")}><span className="ic">🏆</span>Matches</NavLink>
          <NavLink to="/my" className={({ isActive }) => (isActive ? "on" : "")}><span className="ic">🎮</span>My Matches</NavLink>
          <NavLink to="/top" className={({ isActive }) => (isActive ? "on" : "")}><span className="ic">📊</span>Leaderboard</NavLink>
          <NavLink to="/me" className={({ isActive }) => (isActive ? "on" : "")}><span className="ic">👤</span>Profile</NavLink>
        </div>
      </nav>
    </>
  );
}
