import { useEffect, useState, useCallback } from "react";
import { supabase, inr, when } from "../supabase.js";

const STATUSES = ["upcoming", "live", "completed", "cancelled"];

export default function Admin({ profile }) {
  const [tab, setTab] = useState("tournaments");
  const owner = profile?.role === "owner";
  return (
    <>
      <h1>Admin</h1>
      <div className="tabs">
        {[["tournaments", "Tournaments"], ["results", "Results"], ["payouts", "Payouts"]].map(([k, l]) => (
          <div key={k} className={"tab" + (tab === k ? " on" : "")} onClick={() => setTab(k)}>{l}</div>
        ))}
      </div>
      {tab === "tournaments" && <Tournaments />}
      {tab === "results" && <Results />}
      {tab === "payouts" && <Payouts owner={owner} />}
    </>
  );
}

/* ───────────────────────── Tournaments ───────────────────────── */
function Tournaments() {
  const empty = { title: "", game: "BGMI", mode: "solo", entry_fee: 0, prize_text: "", max_slots: 48, start_time: "", rules: "", room_id: "", room_password: "" };
  const [f, setF] = useState(empty);
  const [list, setList] = useState([]);
  const [open, setOpen] = useState(null); // tournament id whose players are shown
  const [players, setPlayers] = useState([]);
  const [rooms, setRooms] = useState({});
  const [err, setErr] = useState("");
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const load = useCallback(async () => {
    const { data } = await supabase.from("tournaments").select("*").order("start_time", { ascending: false });
    setList(data ?? []);
    const { data: rm } = await supabase.from("tournament_rooms").select("*");
    setRooms(Object.fromEntries((rm ?? []).map((x) => [x.tournament_id, x])));
  }, []);
  useEffect(() => { load(); }, [load]);

  async function create(e) {
    e.preventDefault(); setErr("");
    if (!f.title || !f.start_time) return setErr("Title and start time are required");
    const { room_id, room_password, ...t } = f;
    const { data, error } = await supabase.from("tournaments").insert({
      ...t, entry_fee: Number(t.entry_fee), max_slots: Number(t.max_slots), start_time: new Date(t.start_time).toISOString(),
    }).select().single();
    if (error) return setErr(error.message);
    if (room_id) await supabase.from("tournament_rooms").upsert({ tournament_id: data.id, room_id, room_password });
    setF(empty); load();
  }

  async function setStatus(t, status) {
    await supabase.from("tournaments").update({ status }).eq("id", t.id);
    load();
  }
  async function saveRoom(t, room_id, room_password) {
    await supabase.from("tournament_rooms").upsert({ tournament_id: t.id, room_id, room_password, updated_at: new Date().toISOString() });
    load();
  }
  async function showPlayers(t) {
    if (open === t.id) return setOpen(null);
    const { data } = await supabase.from("registrations").select("*").eq("tournament_id", t.id);
    setPlayers(data ?? []); setOpen(t.id);
  }

  return (
    <>
      <form className="card" onSubmit={create}>
        <b>New tournament</b>
        <label>Title</label><input value={f.title} onChange={set("title")} placeholder="Sunday Squad Scrim" />
        <div className="row" style={{ gap: 8 }}>
          <div style={{ flex: 1 }}><label>Game</label><input value={f.game} onChange={set("game")} /></div>
          <div style={{ flex: 1 }}><label>Mode</label>
            <select value={f.mode} onChange={set("mode")}><option>solo</option><option>duo</option><option>squad</option></select></div>
        </div>
        <div className="row" style={{ gap: 8 }}>
          <div style={{ flex: 1 }}><label>Registration fee ₹ (0 = free)</label><input type="number" min="0" value={f.entry_fee} onChange={set("entry_fee")} /></div>
          <div style={{ flex: 1 }}><label>Max slots</label><input type="number" min="1" value={f.max_slots} onChange={set("max_slots")} /></div>
        </div>
        <label>Prizes (shown to players)</label><input value={f.prize_text} onChange={set("prize_text")} placeholder="1st ₹500 · 2nd ₹200" />
        <label>Start time</label><input type="datetime-local" value={f.start_time} onChange={set("start_time")} />
        <label>Rules</label><textarea rows="3" value={f.rules} onChange={set("rules")} />
        <div className="row" style={{ gap: 8 }}>
          <div style={{ flex: 1 }}><label>Room ID (optional now)</label><input value={f.room_id} onChange={set("room_id")} /></div>
          <div style={{ flex: 1 }}><label>Room password</label><input value={f.room_password} onChange={set("room_password")} /></div>
        </div>
        {err && <div className="err">{err}</div>}
        <div style={{ marginTop: 12 }}><button className="btn">Create tournament</button></div>
      </form>

      {list.map((t) => (
        <TournamentRow key={t.id} t={t} room={rooms[t.id]} open={open === t.id} players={players}
          onStatus={setStatus} onRoom={saveRoom} onPlayers={showPlayers} />
      ))}
    </>
  );
}

function TournamentRow({ t, room, open, players, onStatus, onRoom, onPlayers }) {
  const [rid, setRid] = useState(room?.room_id ?? "");
  const [rpw, setRpw] = useState(room?.room_password ?? "");
  return (
    <div className="card">
      <div className="row"><b>{t.title}</b><span className="pill">{inr(t.entry_fee)}</span></div>
      <div className="muted">{t.game} · {t.mode} · {when(t.start_time)}</div>
      <label>Status</label>
      <select value={t.status} onChange={(e) => onStatus(t, e.target.value)}>{STATUSES.map((s) => <option key={s}>{s}</option>)}</select>
      {t.status === "cancelled" && Number(t.entry_fee) > 0 && (
        <div className="banner" style={{ marginTop: 8 }}>Cancelled: refund paid players from the Razorpay dashboard (Payments → Refund).</div>
      )}
      <div className="row" style={{ gap: 8 }}>
        <div style={{ flex: 1 }}><label>Room ID</label><input value={rid} onChange={(e) => setRid(e.target.value)} /></div>
        <div style={{ flex: 1 }}><label>Password</label><input value={rpw} onChange={(e) => setRpw(e.target.value)} /></div>
      </div>
      <div className="row" style={{ marginTop: 10, gap: 8 }}>
        <button className="btn small" onClick={() => onRoom(t, rid, rpw)}>Save room</button>
        <button className="btn small ghost" onClick={() => onPlayers(t)}>{open ? "Hide players" : "Players"}</button>
      </div>
      {open && (
        <div style={{ marginTop: 10 }}>
          {players.length === 0 && <div className="muted">No registrations yet.</div>}
          {players.map((p) => (
            <div className="kv" key={p.id}><span>{p.in_game_name} <span className="muted">{p.in_game_uid}</span></span><span className="pill">{p.payment_status}</span></div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ───────────────────────── Results ───────────────────────── */
function Results() {
  const [rows, setRows] = useState(null);

  const load = useCallback(async () => {
    const { data: rs } = await supabase.from("results").select("*, tournaments(title)").eq("status", "submitted").order("created_at");
    const ids = [...new Set((rs ?? []).map((r) => r.user_id))];
    const { data: ps } = ids.length ? await supabase.from("profiles").select("id,username,upi_id").in("id", ids) : { data: [] };
    const byId = Object.fromEntries((ps ?? []).map((p) => [p.id, p]));
    const withShots = await Promise.all((rs ?? []).map(async (r) => {
      const { data: s } = r.screenshot_path ? await supabase.storage.from("result-screenshots").createSignedUrl(r.screenshot_path, 600) : { data: null };
      return { ...r, player: byId[r.user_id], shot: s?.signedUrl };
    }));
    setRows(withShots);
  }, []);
  useEffect(() => { load(); }, [load]);

  async function decide(r, status) {
    const note = status === "rejected" ? window.prompt("Reason for rejecting?") : null;
    if (status === "rejected" && note === null) return;
    await supabase.from("results").update({ status, admin_note: note }).eq("id", r.id);
    load();
  }

  async function propose(r) {
    const amt = Number(window.prompt(`Prize amount (₹) for ${r.player?.username}?`));
    if (!amt || amt <= 0) return;
    const { error } = await supabase.from("payouts").insert({
      tournament_id: r.tournament_id, user_id: r.user_id, amount: amt, upi_id: r.player?.upi_id ?? null,
    });
    window.alert(error ? error.message : "Payout proposed. The owner must approve it before it can be paid.");
  }

  if (!rows) return <div className="muted">Loading…</div>;
  if (rows.length === 0) return <div className="card muted">No results waiting for verification.</div>;
  return rows.map((r) => (
    <div className="card" key={r.id}>
      <div className="row"><b>{r.player?.username}</b><span className="pill">{r.tournaments?.title}</span></div>
      <div className="muted">Position #{r.position} · {r.kills} kills</div>
      {r.shot && <a href={r.shot} target="_blank" rel="noreferrer"><img className="shot" src={r.shot} alt="result screenshot" /></a>}
      <div className="row" style={{ marginTop: 10, gap: 8 }}>
        <button className="btn small ok" onClick={() => decide(r, "verified")}>Verify</button>
        <button className="btn small bad" onClick={() => decide(r, "rejected")}>Reject</button>
        <button className="btn small ghost" onClick={() => propose(r)}>Propose prize</button>
      </div>
    </div>
  ));
}

/* ───────────────────────── Payouts (owner approval gate) ───────────────────────── */
function Payouts({ owner }) {
  const [rows, setRows] = useState(null);

  const load = useCallback(async () => {
    const { data: ps } = await supabase.from("payouts").select("*, tournaments(title)").order("created_at", { ascending: false });
    const ids = [...new Set((ps ?? []).map((p) => p.user_id))];
    const { data: prof } = ids.length ? await supabase.from("profiles").select("id,username,upi_id").in("id", ids) : { data: [] };
    const byId = Object.fromEntries((prof ?? []).map((p) => [p.id, p]));
    setRows((ps ?? []).map((p) => ({ ...p, player: byId[p.user_id] })));
  }, []);
  useEffect(() => { load(); }, [load]);

  async function setStatus(p, status, extra = {}) {
    const { error } = await supabase.from("payouts").update({ status, ...extra }).eq("id", p.id);
    if (error) window.alert(error.message);
    load();
  }
  async function markPaid(p) {
    const utr = window.prompt(`Send ₹${p.amount} to ${p.upi_id || p.player?.upi_id} first, then enter the UTR / reference number:`);
    if (!utr) return;
    setStatus(p, "paid", { utr });
  }

  if (!rows) return <div className="muted">Loading…</div>;
  return (
    <>
      {!owner && <div className="banner">Only the owner can approve or pay prizes. You can propose prizes from the Results tab.</div>}
      {rows.length === 0 && <div className="card muted">No payouts yet.</div>}
      {rows.map((p) => (
        <div className="card" key={p.id}>
          <div className="row"><b>₹{p.amount} → {p.player?.username}</b>
            <span className={"pill " + (p.status === "paid" ? "ok" : p.status === "rejected" ? "bad" : "warn")}>{p.status}</span></div>
          <div className="muted">{p.tournaments?.title} · UPI: {p.upi_id || p.player?.upi_id || "not set"}</div>
          {p.utr && <div className="muted">Ref: {p.utr}</div>}
          {owner && p.status === "pending_approval" && (
            <div className="row" style={{ marginTop: 10, gap: 8 }}>
              <button className="btn small ok" onClick={() => setStatus(p, "approved")}>Approve</button>
              <button className="btn small bad" onClick={() => setStatus(p, "rejected")}>Reject</button>
            </div>
          )}
          {owner && p.status === "approved" && (
            <div style={{ marginTop: 10 }}><button className="btn small" onClick={() => markPaid(p)}>I've sent it → mark paid</button></div>
          )}
        </div>
      ))}
    </>
  );
}
