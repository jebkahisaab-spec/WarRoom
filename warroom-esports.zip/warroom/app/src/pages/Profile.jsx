import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "../supabase.js";

export default function Profile({ profile, reload, isAdmin }) {
  const [upi, setUpi] = useState("");
  const [stats, setStats] = useState({ matches: 0, wins: 0, kills: 0 });
  const [payouts, setPayouts] = useState([]);
  const [msg, setMsg] = useState("");
  const [showTerms, setShowTerms] = useState(false);

  useEffect(() => { setUpi(profile?.upi_id ?? ""); }, [profile]);
  useEffect(() => {
    if (!profile) return;
    supabase.from("results").select("position,kills,status").eq("user_id", profile.id).eq("status", "verified").then(({ data }) => {
      const d = data ?? [];
      setStats({ matches: d.length, wins: d.filter((x) => x.position === 1).length, kills: d.reduce((a, x) => a + x.kills, 0) });
    });
    supabase.from("payouts").select("*, tournaments(title)").eq("user_id", profile.id).order("created_at", { ascending: false })
      .then(({ data }) => setPayouts(data ?? []));
  }, [profile]);

  async function saveUpi() {
    const { error } = await supabase.from("profiles").update({ upi_id: upi.trim() || null }).eq("id", profile.id);
    setMsg(error ? error.message : "Saved");
    reload();
  }

  if (!profile) return <div className="muted">Loading…</div>;
  return (
    <>
      <h1>{profile.full_name || profile.username}</h1>
      <div className="muted" style={{ marginTop: -8, marginBottom: 12 }}>@{profile.username}</div>
      <div className="card row" style={{ textAlign: "center" }}>
        <div><div className="big">{stats.matches}</div><div className="muted">Matches</div></div>
        <div><div className="big">{stats.wins}</div><div className="muted">Wins</div></div>
        <div><div className="big">{stats.kills}</div><div className="muted">Kills</div></div>
      </div>

      <div className="card">
        <b>Prize payout UPI ID</b>
        <div className="muted">Prizes are sent here after the team approves them. Double-check it, payouts cannot be reversed.</div>
        <input style={{ marginTop: 8 }} placeholder="name@upi" value={upi} onChange={(e) => setUpi(e.target.value)} />
        <div style={{ marginTop: 10 }}><button className="btn small" onClick={saveUpi}>Save</button> {msg && <span className="msg">{msg}</span>}</div>
      </div>

      <h2>My prizes</h2>
      {payouts.length === 0 && <div className="card muted">No prizes yet.</div>}
      {payouts.map((p) => (
        <div className="card row" key={p.id}>
          <div><b>₹{p.amount}</b><div className="muted">{p.tournaments?.title}</div></div>
          <span className={"pill " + (p.status === "paid" ? "ok" : p.status === "rejected" ? "bad" : "warn")}>
            {p.status === "pending_approval" ? "awaiting approval" : p.status}
          </span>
        </div>
      ))}

      <div className="stack" style={{ marginTop: 16 }}>
        {isAdmin && <Link to="/admin"><button className="btn">Admin panel</button></Link>}
        <button className="btn ghost" onClick={() => setShowTerms(!showTerms)}>Terms &amp; Conditions</button>
        {showTerms && (
          <div className="card muted" style={{ fontSize: 13 }}>
            <p>• Players pay a one-time registration fee per tournament. There is no wallet, no coins and no betting.</p>
            <p>• Prizes are performance-based and are paid only after results are verified and approved by the organisers.</p>
            <p>• Paid tournaments are for players aged 18 and above.</p>
            <p>• Cheating, hacks, emulators where not allowed, or fake result screenshots lead to disqualification.</p>
            <p>• If a tournament is cancelled, the registration fee is refunded.</p>
            <p>• Organiser decisions on disputes are final.</p>
          </div>
        )}
        <button className="btn ghost" onClick={() => supabase.auth.signOut()}>Log out</button>
      </div>
    </>
  );
}
