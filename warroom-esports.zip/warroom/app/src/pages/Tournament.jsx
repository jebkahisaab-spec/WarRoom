import { useEffect, useState, useCallback } from "react";
import { useParams, Link } from "react-router-dom";
import { supabase, inr, when, isAdult } from "../supabase.js";

export default function Tournament({ profile }) {
  const { id } = useParams();
  const [t, setT] = useState(null);
  const [taken, setTaken] = useState(0);
  const [reg, setReg] = useState(null);
  const [room, setRoom] = useState(null);
  const [result, setResult] = useState(null);
  const [payouts, setPayouts] = useState([]);
  const [f, setF] = useState({ name: "", uid: "" });
  const [r, setR] = useState({ position: "", kills: "", file: null });
  const [busy, setBusy] = useState(false);
  const [qr, setQr] = useState(null);      // live payment QR: { image_url, amount, expires_at }
  const [left, setLeft] = useState(0);     // seconds until the QR expires
  const [qrExpired, setQrExpired] = useState(false);
  const [err, setErr] = useState("");
  const [msg, setMsg] = useState("");

  const load = useCallback(async () => {
    const { data: tt } = await supabase.from("tournaments").select("*").eq("id", id).single();
    setT(tt);
    const { data: n } = await supabase.rpc("slots_taken", { p_tournament: id });
    setTaken(n ?? 0);
    if (!profile) return;
    const { data: rg } = await supabase.from("registrations").select("*")
      .eq("tournament_id", id).eq("user_id", profile.id).maybeSingle();
    setReg(rg);
    if (rg) {
      const { data: rm } = await supabase.from("tournament_rooms").select("*").eq("tournament_id", id).maybeSingle();
      setRoom(rm);
    }
    const { data: rs } = await supabase.from("results").select("*").eq("tournament_id", id).eq("user_id", profile.id).maybeSingle();
    setResult(rs);
    const { data: po } = await supabase.from("payouts").select("*").eq("tournament_id", id).eq("user_id", profile.id);
    setPayouts(po ?? []);
  }, [id, profile]);
  useEffect(() => { load(); }, [load]);

  // While a QR is showing: tick the countdown every second, check for the payment every 3 seconds.
  useEffect(() => {
    if (!qr || !profile) return;
    const expiry = new Date(qr.expires_at).getTime();
    const tick = setInterval(() => {
      const s = Math.max(0, Math.ceil((expiry - Date.now()) / 1000));
      setLeft(s);
      if (s === 0) { setQr(null); setQrExpired(true); }
    }, 1000);
    const poll = setInterval(async () => {
      const { data } = await supabase.from("registrations").select("id")
        .eq("tournament_id", id).eq("user_id", profile.id).maybeSingle();
      if (data) { setQr(null); setMsg("Payment received. You are registered!"); load(); }
    }, 3000);
    setLeft(Math.max(0, Math.ceil((expiry - Date.now()) / 1000)));
    return () => { clearInterval(tick); clearInterval(poll); };
  }, [qr, id, profile, load]);

  async function join() {
    setErr(""); setMsg("");
    if (!f.name.trim()) return setErr("Enter your in-game name");
    setBusy(true);
    try {
      if (Number(t.entry_fee) === 0) {
        const { error } = await supabase.rpc("join_free_tournament", { p_tournament: id, p_in_game_name: f.name.trim(), p_in_game_uid: f.uid.trim() });
        if (error) throw error;
        setMsg("You're in!");
        setBusy(false);
        return load();
      }
      if (!isAdult(profile?.dob)) throw new Error("Paid tournaments are for players aged 18 and above.");
      const { data, error } = await supabase.functions.invoke("create-qr", {
        body: { tournament_id: id, in_game_name: f.name.trim(), in_game_uid: f.uid.trim() },
      });
      if (error) throw new Error((await error.context?.json?.().catch(() => null))?.error ?? error.message);
      if (data?.error) throw new Error(data.error);
      setQrExpired(false);
      setQr(data);          // shows the QR card with the 5-minute countdown
      setBusy(false);
    } catch (e) {
      setErr(e.message); setBusy(false);
    }
  }

  async function submitResult() {
    setErr(""); setMsg("");
    if (!r.file) return setErr("Upload your result screenshot");
    if (!r.position || r.kills === "") return setErr("Enter your position and kills");
    setBusy(true);
    try {
      const ext = (r.file.name.split(".").pop() || "jpg").toLowerCase();
      const path = `${profile.id}/${id}-${Date.now()}.${ext}`;
      const up = await supabase.storage.from("result-screenshots").upload(path, r.file);
      if (up.error) throw up.error;
      const { error } = await supabase.from("results").insert({
        tournament_id: id, user_id: profile.id, position: Number(r.position), kills: Number(r.kills), screenshot_path: path,
      });
      if (error) throw error;
      setMsg("Result submitted. We'll verify it shortly.");
      load();
    } catch (e) { setErr(e.message); }
    setBusy(false);
  }

  if (!t) return <div className="muted">Loading…</div>;
  const full = taken >= t.max_slots;
  const canJoin = !reg && t.status === "upcoming" && !full;
  const canSubmit = reg && !result && (t.status === "live" || t.status === "completed");

  return (
    <>
      <Link to="/" className="muted">← Back</Link>
      <h1 style={{ marginTop: 8 }}>{t.title}</h1>
      <div className="card">
        <div className="kv"><span className="muted">Game</span><b>{t.game} · {t.mode}</b></div>
        <div className="kv"><span className="muted">Registration fee</span><b>{inr(t.entry_fee)}</b></div>
        <div className="kv"><span className="muted">Prizes</span><b>{t.prize_text || "—"}</b></div>
        <div className="kv"><span className="muted">Starts</span><b>{when(t.start_time)}</b></div>
        <div className="kv"><span className="muted">Slots</span><b>{taken}/{t.max_slots}</b></div>
        <div className="kv"><span className="muted">Status</span><span className="pill">{t.status}</span></div>
      </div>
      {t.rules && <div className="card"><b>Rules</b><div className="muted" style={{ whiteSpace: "pre-wrap", marginTop: 6 }}>{t.rules}</div></div>}

      {reg && (
        <div className="card">
          <span className="pill ok">Registered</span> as <b>{reg.in_game_name}</b>
          {room?.room_id ? (
            <div style={{ marginTop: 10 }}>
              <div className="kv"><span className="muted">Room ID</span><b>{room.room_id}</b></div>
              <div className="kv"><span className="muted">Password</span><b>{room.room_password}</b></div>
            </div>
          ) : <div className="muted" style={{ marginTop: 8 }}>Room ID and password will appear here before the match starts.</div>}
        </div>
      )}

      {qr && (
        <div className="card" style={{ textAlign: "center" }}>
          <b>Scan &amp; pay {inr(qr.amount)}</b>
          <div className="muted">Registration fee · {qr.title}</div>
          <img src={qr.image_url} alt="UPI payment QR" style={{ width: 240, maxWidth: "80%", background: "#fff", borderRadius: 14, padding: 10, margin: "12px auto", display: "block" }} />
          <div className="big">{String(Math.floor(left / 60)).padStart(2, "0")}:{String(left % 60).padStart(2, "0")}</div>
          <div className="muted">This QR expires in 5 minutes. Pay exactly {inr(qr.amount)}.</div>
          <div className="muted" style={{ marginTop: 10, textAlign: "left" }}>
            • Scan with any UPI app (Google Pay, PhonePe, Paytm…)<br />
            • Paying from this same phone? Take a screenshot, then use <b>“Scan from gallery”</b> in your UPI app<br />
            • You'll be registered automatically within seconds of paying. Don't close this screen.
          </div>
          <div className="row" style={{ marginTop: 12, gap: 8 }}>
            <a className="btn small ghost" href={qr.image_url} target="_blank" rel="noreferrer" style={{ flex: 1 }}>Open QR image</a>
            <button className="btn small ghost" style={{ flex: 1 }} onClick={() => setQr(null)}>Cancel</button>
          </div>
        </div>
      )}
      {qrExpired && !qr && !reg && (
        <div className="card" style={{ textAlign: "center" }}>
          <span className="pill bad">QR expired</span>
          <div className="muted" style={{ margin: "8px 0 12px" }}>If you already paid, wait a minute: you'll be registered automatically. Otherwise get a fresh QR.</div>
          <button className="btn" disabled={busy} onClick={join}>Get a new QR</button>
        </div>
      )}

      {canJoin && !qr && !qrExpired && (
        <div className="card">
          <b>Join this tournament</b>
          <label>In-game name</label><input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
          <label>In-game UID (optional)</label><input value={f.uid} onChange={(e) => setF({ ...f, uid: e.target.value })} inputMode="numeric" />
          {Number(t.entry_fee) > 0 && <div className="muted" style={{ marginTop: 8 }}>You pay a one-time registration fee of {inr(t.entry_fee)} by scanning a UPI QR (valid for 5 minutes). 18+ only.</div>}
          <div style={{ marginTop: 12 }}>
            <button className="btn" disabled={busy} onClick={join}>{busy ? "Please wait…" : Number(t.entry_fee) > 0 ? `Pay ${inr(t.entry_fee)} & get QR` : "Join Free"}</button>
          </div>
        </div>
      )}
      {!reg && full && t.status === "upcoming" && <div className="card muted">This tournament is full.</div>}

      {canSubmit && (
        <div className="card">
          <b>Submit your result</b>
          <label>Final position</label><input type="number" min="1" value={r.position} onChange={(e) => setR({ ...r, position: e.target.value })} />
          <label>Kills</label><input type="number" min="0" value={r.kills} onChange={(e) => setR({ ...r, kills: e.target.value })} />
          <label>Result screenshot</label><input type="file" accept="image/*" onChange={(e) => setR({ ...r, file: e.target.files?.[0] ?? null })} />
          <div style={{ marginTop: 12 }}><button className="btn" disabled={busy} onClick={submitResult}>Submit result</button></div>
        </div>
      )}
      {result && (
        <div className="card">
          <b>Your result</b>
          <div className="kv"><span className="muted">Position / Kills</span><b>#{result.position} · {result.kills} kills</b></div>
          <div className="kv"><span className="muted">Status</span><span className={"pill " + (result.status === "verified" ? "ok" : result.status === "rejected" ? "bad" : "warn")}>{result.status}</span></div>
          {result.admin_note && <div className="muted">{result.admin_note}</div>}
        </div>
      )}
      {payouts.map((p) => (
        <div className="card" key={p.id}>
          <b>Prize ₹{p.amount}</b>{" "}
          <span className={"pill " + (p.status === "paid" ? "ok" : p.status === "rejected" ? "bad" : "warn")}>
            {p.status === "pending_approval" ? "awaiting approval" : p.status}
          </span>
          {p.status === "paid" && p.utr && <div className="muted">Reference: {p.utr}</div>}
        </div>
      ))}
      {err && <div className="err">{err}</div>}
      {msg && <div className="msg">{msg}</div>}
    </>
  );
}
