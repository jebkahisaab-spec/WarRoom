import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { supabase, when, inr } from "../supabase.js";

export default function MyMatches() {
  const [rows, setRows] = useState(null);
  const [tab, setTab] = useState("upcoming");

  useEffect(() => {
    supabase.from("registrations").select("*, tournaments(*)").order("created_at", { ascending: false })
      .then(({ data }) => setRows(data ?? []));
  }, []);

  const groups = {
    upcoming: (r) => r.tournaments?.status === "upcoming",
    live: (r) => r.tournaments?.status === "live",
    done: (r) => ["completed", "cancelled"].includes(r.tournaments?.status),
  };
  const shown = (rows ?? []).filter(groups[tab]);

  return (
    <>
      <h1>My Matches</h1>
      <div className="tabs">
        {[["upcoming", "Upcoming"], ["live", "Ongoing"], ["done", "Completed"]].map(([k, l]) => (
          <div key={k} className={"tab" + (tab === k ? " on" : "")} onClick={() => setTab(k)}>{l}</div>
        ))}
      </div>
      {rows === null && <div className="muted">Loading…</div>}
      {rows && shown.length === 0 && <div className="card muted">Nothing here yet. <Link to="/">Browse tournaments</Link></div>}
      {shown.map((r) => (
        <Link key={r.id} to={`/t/${r.tournament_id}`}>
          <div className="card">
            <div className="row"><b style={{ color: "var(--text)" }}>{r.tournaments.title}</b><span className="pill">{inr(r.tournaments.entry_fee)}</span></div>
            <div className="muted">{r.tournaments.game} · {when(r.tournaments.start_time)}</div>
          </div>
        </Link>
      ))}
    </>
  );
}
