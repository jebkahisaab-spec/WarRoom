import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { supabase, inr, when } from "../supabase.js";

export default function Home() {
  const [list, setList] = useState(null);
  const [filter, setFilter] = useState("all");

  useEffect(() => {
    (async () => {
      const { data } = await supabase.from("tournaments").select("*")
        .in("status", ["upcoming", "live"]).order("start_time");
      const withSlots = await Promise.all((data ?? []).map(async (t) => {
        const { data: n } = await supabase.rpc("slots_taken", { p_tournament: t.id });
        return { ...t, taken: n ?? 0 };
      }));
      setList(withSlots);
    })();
  }, []);

  const shown = (list ?? []).filter((t) => filter === "all" || (filter === "free" ? Number(t.entry_fee) === 0 : Number(t.entry_fee) > 0));

  return (
    <>
      <h1>Tournaments</h1>
      <div className="tabs">
        {["all", "free", "paid"].map((k) => (
          <div key={k} className={"tab" + (filter === k ? " on" : "")} onClick={() => setFilter(k)}>
            {k === "all" ? "All" : k === "free" ? "Free" : "Paid"}
          </div>
        ))}
      </div>
      {list === null && <div className="muted">Loading…</div>}
      {list && shown.length === 0 && <div className="card muted">No tournaments right now. Check back soon!</div>}
      {shown.map((t) => (
        <Link to={`/t/${t.id}`} key={t.id}>
          <div className="card">
            <div className="row">
              <span className="pill">{t.game} · {t.mode}</span>
              <span className={"pill " + (Number(t.entry_fee) === 0 ? "free" : "")}>{inr(t.entry_fee)}</span>
            </div>
            <h2 style={{ color: "var(--text)", marginTop: 10 }}>{t.title}</h2>
            {t.prize_text && <div className="muted">🏅 {t.prize_text}</div>}
            <div className="row" style={{ marginTop: 10 }}>
              <span className="muted">🕒 {when(t.start_time)}</span>
              <span className="muted">{t.taken}/{t.max_slots} slots {t.status === "live" && <span className="pill ok">LIVE</span>}</span>
            </div>
          </div>
        </Link>
      ))}
    </>
  );
}
