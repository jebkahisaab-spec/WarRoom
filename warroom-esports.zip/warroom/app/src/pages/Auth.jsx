import { useState } from "react";
import { supabase, configured } from "../supabase.js";

export default function Auth() {
  const [mode, setMode] = useState("login");
  const [f, setF] = useState({ email: "", password: "", username: "", full_name: "", phone: "", dob: "" });
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [msg, setMsg] = useState("");
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  async function submit(e) {
    e.preventDefault();
    setErr(""); setMsg(""); setBusy(true);
    try {
      if (mode === "login") {
        const { error } = await supabase.auth.signInWithPassword({ email: f.email, password: f.password });
        if (error) throw error;
      } else {
        if (!/^[a-zA-Z0-9_]{3,24}$/.test(f.username)) throw new Error("Username: 3–24 letters, numbers or _");
        if (!f.dob) throw new Error("Date of birth is required");
        if (f.password.length < 6) throw new Error("Password must be at least 6 characters");
        const { data, error } = await supabase.auth.signUp({
          email: f.email,
          password: f.password,
          options: { data: { username: f.username, full_name: f.full_name, phone: f.phone, dob: f.dob } },
        });
        if (error) throw error;
        if (!data.session) setMsg("Account created. Check your email to confirm, then log in.");
      }
    } catch (e2) {
      setErr(e2.message?.includes("duplicate") ? "That username is already taken" : e2.message);
    } finally { setBusy(false); }
  }

  return (
    <div className="shell auth">
      <svg className="hero-mark" viewBox="0 0 64 64" fill="none" stroke="#ffd400" strokeWidth="3">
        <circle cx="32" cy="32" r="22" /><circle cx="32" cy="32" r="6" fill="#ffd400" />
        <path d="M32 4v14M32 46v14M4 32h14M46 32h14" />
      </svg>
      <div style={{ textAlign: "center", marginBottom: 18 }}>
        <div className="brand" style={{ fontSize: 28 }}>WAR<span>ROOM</span></div>
        <div className="muted">ESPORTS TOURNAMENTS</div>
      </div>
      {!configured && <div className="banner">App not configured: add Supabase URL and key in .env</div>}
      <form className="card" onSubmit={submit}>
        <h1>{mode === "login" ? "Welcome back" : "Create your account"}</h1>
        {mode === "signup" && (
          <>
            <label>Username</label><input value={f.username} onChange={set("username")} autoCapitalize="none" required />
            <label>Full name</label><input value={f.full_name} onChange={set("full_name")} />
            <label>Phone</label><input value={f.phone} onChange={set("phone")} inputMode="tel" />
            <label>Date of birth</label><input type="date" value={f.dob} onChange={set("dob")} required />
            <div className="muted" style={{ marginTop: 6 }}>Paid tournaments are for players aged 18+. Free matches are open to everyone.</div>
          </>
        )}
        <label>Email</label><input type="email" value={f.email} onChange={set("email")} required />
        <label>Password</label><input type="password" value={f.password} onChange={set("password")} required />
        {err && <div className="err">{err}</div>}
        {msg && <div className="msg">{msg}</div>}
        <div style={{ marginTop: 14 }}>
          <button className="btn" disabled={busy}>{busy ? "Please wait…" : mode === "login" ? "Log In" : "Register"}</button>
        </div>
        <div className="muted" style={{ textAlign: "center", marginTop: 14 }}>
          {mode === "login" ? "Don't have an account? " : "Already registered? "}
          <a href="#/" onClick={(e) => { e.preventDefault(); setMode(mode === "login" ? "signup" : "login"); setErr(""); }}>
            {mode === "login" ? "Register" : "Log in"}
          </a>
        </div>
      </form>
    </div>
  );
}
