import { useEffect, useState } from "react";
import { supabase } from "../supabase.js";

export default function Leaderboard() {
  const [days, setDays] = useState(7);
  const [rows, setRows] = useState(null);

  useEffect(() => {
    setRows(null);
    supabase.rpc("get_leaderboard", { p_days: days }).then(({ data }) => setRows(data ?? []));
  }, [days]);

  return (
    <>
      <h1>Leaderboard</h1>
      <div className="muted" style={{ marginBottom: 8 }}>Only verified match results count.</div>
      <div className="tabs">
        {[[7, "7 Days"], [30, "30 Days"], [null, "All Time"]].map(([d, l]) => (
          <div key={l} className={"tab" + (days === d ? " on" : "")} onClick={() => setDays(d)}>{l}</div>
        ))}
      </div>
      {rows === null && <div className="muted">Loading…</div>}
      {rows && rows.length === 0 && <div className="card muted">No verified results yet.</div>}
      {(rows ?? []).map((p, i) => (
        <div className="card row" key={p.username}>
          <div><b>#{i + 1} {p.username}</b><div className="muted">{p.matches} matches · {p.kills} kills</div></div>
          <div className="big">{p.wins}<span className="muted"> wins</span></div>
        </div>
      ))}
    </>
  );
}
