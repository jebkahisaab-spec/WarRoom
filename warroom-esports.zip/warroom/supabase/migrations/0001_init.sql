-- WarRoom esports tournaments: schema + RLS
-- Money rules baked in:
--   * players pay a registration fee per tournament (no wallet, no coins)
--   * prizes are NEVER paid automatically: admin proposes -> OWNER approves -> OWNER marks paid

-- ───────────── profiles ─────────────
create table public.profiles (
  id          uuid primary key references auth.users(id) on delete cascade,
  username    text unique not null check (char_length(username) between 3 and 24),
  full_name   text,
  phone       text,
  dob         date not null,
  upi_id      text,
  role        text not null default 'player' check (role in ('player','admin','owner')),
  created_at  timestamptz not null default now()
);

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role in ('admin','owner'));
$$;

create or replace function public.is_owner() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'owner');
$$;

create or replace function public.is_adult(p_user uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select dob <= (current_date - interval '18 years') from public.profiles where id = p_user), false);
$$;

-- a player can never change their own role (only owner, or SQL editor / service role)
create or replace function public.protect_role() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is not null and not public.is_owner() then
    new.role := old.role;
  end if;
  return new;
end $$;
create trigger trg_protect_role before update on public.profiles
  for each row execute function public.protect_role();

-- create profile automatically after signup (username + dob come from signup metadata)
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, username, full_name, phone, dob)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'username', 'player' || substr(new.id::text, 1, 8)),
    new.raw_user_meta_data->>'full_name',
    new.raw_user_meta_data->>'phone',
    coalesce((new.raw_user_meta_data->>'dob')::date, current_date)
  );
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

alter table public.profiles enable row level security;
create policy "profiles read own or admin" on public.profiles for select
  using (id = auth.uid() or public.is_admin());
create policy "profiles update own" on public.profiles for update
  using (id = auth.uid()) with check (id = auth.uid());
create policy "profiles owner updates" on public.profiles for update
  using (public.is_owner());

-- ───────────── tournaments ─────────────
create table public.tournaments (
  id           uuid primary key default gen_random_uuid(),
  title        text not null,
  game         text not null,                       -- e.g. BGMI, Free Fire
  mode         text not null default 'solo' check (mode in ('solo','duo','squad')),
  entry_fee    numeric(10,2) not null default 0 check (entry_fee >= 0),   -- registration fee in INR
  prize_text   text,                                -- shown to players, e.g. "1st ₹500, 2nd ₹200"
  max_slots    int  not null default 48 check (max_slots > 0),
  start_time   timestamptz not null,
  status       text not null default 'upcoming' check (status in ('upcoming','live','completed','cancelled')),
  rules        text,
  created_at   timestamptz not null default now()
);
alter table public.tournaments enable row level security;
create policy "tournaments public read" on public.tournaments for select using (true);
create policy "tournaments admin write" on public.tournaments for all
  using (public.is_admin()) with check (public.is_admin());

-- room credentials kept apart so only registered players can see them
create table public.tournament_rooms (
  tournament_id uuid primary key references public.tournaments(id) on delete cascade,
  room_id       text,
  room_password text,
  updated_at    timestamptz not null default now()
);
alter table public.tournament_rooms enable row level security;

-- ───────────── registrations (written ONLY by server functions) ─────────────
create table public.registrations (
  id             uuid primary key default gen_random_uuid(),
  tournament_id  uuid not null references public.tournaments(id) on delete cascade,
  user_id        uuid not null references auth.users(id) on delete cascade,
  in_game_name   text not null,
  in_game_uid    text,
  payment_status text not null default 'free' check (payment_status in ('free','paid','refunded')),
  created_at     timestamptz not null default now(),
  unique (tournament_id, user_id)
);
alter table public.registrations enable row level security;
create policy "registrations read own or admin" on public.registrations for select
  using (user_id = auth.uid() or public.is_admin());
-- no insert/update/delete policies for players: joining goes through join_free_tournament() or the payment webhook

create policy "rooms visible to registered players" on public.tournament_rooms for select
  using (
    public.is_admin() or exists (
      select 1 from public.registrations r
      where r.tournament_id = tournament_rooms.tournament_id and r.user_id = auth.uid()
        and r.payment_status in ('free','paid')
    )
  );
create policy "rooms admin write" on public.tournament_rooms for all
  using (public.is_admin()) with check (public.is_admin());

-- how many slots are taken (public, without exposing who)
create or replace function public.slots_taken(p_tournament uuid) returns int
language sql stable security definer set search_path = public as $$
  select count(*)::int from public.registrations
  where tournament_id = p_tournament and payment_status in ('free','paid');
$$;

-- free tournaments: join directly (18+ NOT required for free matches)
create or replace function public.join_free_tournament(p_tournament uuid, p_in_game_name text, p_in_game_uid text)
returns uuid language plpgsql security definer set search_path = public as $$
declare t public.tournaments; new_id uuid;
begin
  if auth.uid() is null then raise exception 'login required'; end if;
  select * into t from public.tournaments where id = p_tournament;
  if t.id is null then raise exception 'tournament not found'; end if;
  if t.entry_fee > 0 then raise exception 'this tournament has a registration fee: pay first'; end if;
  if t.status <> 'upcoming' then raise exception 'registration closed'; end if;
  if public.slots_taken(t.id) >= t.max_slots then raise exception 'tournament full'; end if;
  insert into public.registrations (tournament_id, user_id, in_game_name, in_game_uid, payment_status)
  values (t.id, auth.uid(), p_in_game_name, p_in_game_uid, 'free')
  returning id into new_id;
  return new_id;
end $$;

-- ───────────── payments (registration fees; written by edge functions with service role) ─────────────
create table public.payments (
  id                 uuid primary key default gen_random_uuid(),
  user_id            uuid not null references auth.users(id) on delete cascade,
  tournament_id      uuid not null references public.tournaments(id) on delete cascade,
  in_game_name       text not null,
  in_game_uid        text,
  gateway_order_id   text unique not null,
  gateway_payment_id text,
  amount             numeric(10,2) not null,
  status             text not null default 'created' check (status in ('created','paid','failed','refunded')),
  created_at         timestamptz not null default now()
);
alter table public.payments enable row level security;
create policy "payments read own or admin" on public.payments for select
  using (user_id = auth.uid() or public.is_admin());

-- ───────────── results ─────────────
create table public.results (
  id             uuid primary key default gen_random_uuid(),
  tournament_id  uuid not null references public.tournaments(id) on delete cascade,
  user_id        uuid not null references auth.users(id) on delete cascade,
  position       int check (position > 0),
  kills          int not null default 0 check (kills >= 0),
  screenshot_path text,
  status         text not null default 'submitted' check (status in ('submitted','verified','rejected')),
  admin_note     text,
  created_at     timestamptz not null default now(),
  unique (tournament_id, user_id)
);
alter table public.results enable row level security;
create policy "results read own or admin" on public.results for select
  using (user_id = auth.uid() or public.is_admin());
create policy "results submit own" on public.results for insert
  with check (
    user_id = auth.uid() and status = 'submitted' and exists (
      select 1 from public.registrations r
      where r.tournament_id = results.tournament_id and r.user_id = auth.uid()
        and r.payment_status in ('free','paid')
    )
  );
create policy "results admin update" on public.results for update
  using (public.is_admin()) with check (public.is_admin());

-- ───────────── payouts: THE APPROVAL GATE ─────────────
-- admin proposes (pending_approval) -> owner approves (approved) -> owner marks paid after sending money.
create table public.payouts (
  id             uuid primary key default gen_random_uuid(),
  tournament_id  uuid not null references public.tournaments(id) on delete cascade,
  user_id        uuid not null references auth.users(id) on delete cascade,
  amount         numeric(10,2) not null check (amount > 0),
  upi_id         text,
  status         text not null default 'pending_approval'
                 check (status in ('pending_approval','approved','paid','rejected')),
  proposed_by    uuid references auth.users(id),
  approved_by    uuid references auth.users(id),
  approved_at    timestamptz,
  paid_at        timestamptz,
  utr            text,                -- bank/UPI reference after you send the money
  note           text,
  created_at     timestamptz not null default now()
);
alter table public.payouts enable row level security;
create policy "payouts read own or admin" on public.payouts for select
  using (user_id = auth.uid() or public.is_admin());
create policy "payouts admin propose" on public.payouts for insert
  with check (public.is_admin() and status = 'pending_approval');
create policy "payouts owner decides" on public.payouts for update
  using (public.is_owner()) with check (public.is_owner());
create policy "payouts owner delete" on public.payouts for delete using (public.is_owner());

-- stamp approver/time automatically when the owner changes status
create or replace function public.stamp_payout() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.status = 'approved' and old.status <> 'approved' then
    new.approved_by := auth.uid(); new.approved_at := now();
  elsif new.status = 'paid' and old.status <> 'paid' then
    if old.status <> 'approved' then raise exception 'payout must be approved before it can be marked paid'; end if;
    new.paid_at := now();
  end if;
  return new;
end $$;
create trigger trg_stamp_payout before update on public.payouts
  for each row execute function public.stamp_payout();

-- ───────────── leaderboard (public, aggregated; shows verified results only) ─────────────
create or replace function public.get_leaderboard(p_days int default 7)
returns table (username text, matches bigint, wins bigint, kills bigint)
language sql stable security definer set search_path = public as $$
  select p.username,
         count(*)                                   as matches,
         count(*) filter (where r.position = 1)     as wins,
         coalesce(sum(r.kills), 0)::bigint          as kills
  from public.results r
  join public.profiles p on p.id = r.user_id
  where r.status = 'verified'
    and (p_days is null or r.created_at >= now() - make_interval(days => p_days))
  group by p.username
  order by wins desc, kills desc
  limit 50;
$$;

-- ───────────── storage for result screenshots (private; each user writes to their own folder) ─────────────
insert into storage.buckets (id, name, public) values ('result-screenshots', 'result-screenshots', false)
on conflict (id) do nothing;

create policy "screenshots upload own folder" on storage.objects for insert to authenticated
  with check (bucket_id = 'result-screenshots' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "screenshots read own or admin" on storage.objects for select to authenticated
  using (bucket_id = 'result-screenshots' and ((storage.foldername(name))[1] = auth.uid()::text or public.is_admin()));
