-- Payments now use a single-use UPI QR that is valid for 5 minutes.
-- payments.gateway_order_id stores the Razorpay QR code id (qr_...).

alter table public.payments
  add column if not exists expires_at   timestamptz,
  add column if not exists qr_image_url text;

alter table public.payments drop constraint if exists payments_status_check;
alter table public.payments add constraint payments_status_check
  check (status in ('created','paid','failed','refunded','expired'));

-- A slot is held while a player has an unexpired, unpaid QR open,
-- so the tournament can't be oversold while people are paying.
create or replace function public.slots_taken(p_tournament uuid) returns int
language sql stable security definer set search_path = public as $$
  select (
    (select count(*) from public.registrations
       where tournament_id = p_tournament and payment_status in ('free','paid'))
    +
    (select count(*) from public.payments p
       where p.tournament_id = p_tournament
         and p.status = 'created'
         and p.expires_at > now()
         and not exists (select 1 from public.registrations r
                         where r.tournament_id = p.tournament_id and r.user_id = p.user_id))
  )::int;
$$;
