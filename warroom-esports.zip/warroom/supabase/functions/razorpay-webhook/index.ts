// Razorpay webhook: a payment made on a player's QR code confirms the registration.
// Deploy with --no-verify-jwt (Razorpay calls it, not a logged-in user).
// Secret needed: RAZORPAY_WEBHOOK_SECRET (the secret you set on the webhook in the Razorpay dashboard).
// In the Razorpay dashboard subscribe to the event:  qr_code.credited
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

async function hmacHex(secret: string, body: string) {
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const sig = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(body));
  return [...new Uint8Array(sig)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

Deno.serve(async (req) => {
  const raw = await req.text();
  const signature = req.headers.get("x-razorpay-signature") ?? "";
  const expected = await hmacHex(Deno.env.get("RAZORPAY_WEBHOOK_SECRET")!, raw);
  if (signature !== expected) return new Response("bad signature", { status: 401 });

  const event = JSON.parse(raw);
  if (event.event !== "qr_code.credited") return new Response("ignored");

  const qrId = event.payload?.qr_code?.entity?.id;
  const payment = event.payload?.payment?.entity;
  if (!qrId || !payment) return new Response("bad payload", { status: 400 });

  const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);

  const { data: p } = await admin.from("payments").select("*").eq("gateway_order_id", qrId).single();
  if (!p) return new Response("unknown qr", { status: 404 });
  if (p.status === "paid") return new Response("already processed");

  // the amount paid must match the registration fee
  if (Number(payment.amount) !== Math.round(Number(p.amount) * 100)) {
    await admin.from("payments").update({ status: "failed", gateway_payment_id: payment.id }).eq("id", p.id);
    return new Response("amount mismatch", { status: 400 });
  }

  await admin.from("payments").update({ status: "paid", gateway_payment_id: payment.id }).eq("id", p.id);

  await admin.from("registrations").upsert({
    tournament_id: p.tournament_id,
    user_id: p.user_id,
    in_game_name: p.in_game_name,
    in_game_uid: p.in_game_uid,
    payment_status: "paid",
  }, { onConflict: "tournament_id,user_id" });

  return new Response("ok");
});
