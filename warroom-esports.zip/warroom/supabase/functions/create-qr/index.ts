// Creates a single-use, fixed-amount UPI QR (valid 5 minutes) for a tournament registration fee.
// Secrets needed: RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET
// NOTE: Razorpay "UPI QR" is an on-demand feature: ask Razorpay support to activate it on your account.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const QR_LIFETIME_SECONDS = 5 * 60; // Razorpay minimum is 2 minutes, maximum 2 hours

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};
const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const url = Deno.env.get("SUPABASE_URL")!;

    // who is calling?
    const userClient = createClient(url, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: req.headers.get("Authorization") ?? "" } },
    });
    const { data: { user } } = await userClient.auth.getUser();
    if (!user) return json({ error: "login required" }, 401);

    const { tournament_id, in_game_name, in_game_uid } = await req.json();
    if (!tournament_id || !in_game_name) return json({ error: "tournament_id and in_game_name required" }, 400);

    const admin = createClient(url, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);

    const { data: t } = await admin.from("tournaments").select("*").eq("id", tournament_id).single();
    if (!t) return json({ error: "tournament not found" }, 404);
    if (t.status !== "upcoming") return json({ error: "registration closed" }, 400);
    if (Number(t.entry_fee) <= 0) return json({ error: "this tournament is free: use the free join" }, 400);

    const { data: existing } = await admin.from("registrations")
      .select("id").eq("tournament_id", t.id).eq("user_id", user.id).maybeSingle();
    if (existing) return json({ error: "already registered" }, 400);

    // paid tournaments are 18+ only
    const { data: adult } = await admin.rpc("is_adult", { p_user: user.id });
    if (!adult) return json({ error: "paid tournaments are for players aged 18 and above" }, 403);

    // already has a live QR for this tournament? show the same one (no QR spam, no double slot hold)
    const { data: pending } = await admin.from("payments").select("*")
      .eq("user_id", user.id).eq("tournament_id", t.id).eq("status", "created")
      .gt("expires_at", new Date().toISOString()).maybeSingle();
    if (pending) {
      return json({
        qr_id: pending.gateway_order_id, image_url: pending.qr_image_url,
        amount: Number(pending.amount), expires_at: pending.expires_at, title: t.title,
      });
    }

    // slots (this also counts other players' unexpired QRs as held slots)
    const { data: taken } = await admin.rpc("slots_taken", { p_tournament: t.id });
    if ((taken ?? 0) >= t.max_slots) return json({ error: "tournament full (slots are held for players who are paying right now, try again in a few minutes)" }, 400);

    const keyId = Deno.env.get("RAZORPAY_KEY_ID")!;
    const keySecret = Deno.env.get("RAZORPAY_KEY_SECRET")!;

    const rz = await fetch("https://api.razorpay.com/v1/payments/qr_codes", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: "Basic " + btoa(`${keyId}:${keySecret}`) },
      body: JSON.stringify({
        type: "upi_qr",
        name: "WarRoom Esports",
        usage: "single_use",
        fixed_amount: true,
        payment_amount: Math.round(Number(t.entry_fee) * 100), // paise
        description: `Registration fee: ${t.title}`.slice(0, 250),
        close_by: Math.floor(Date.now() / 1000) + QR_LIFETIME_SECONDS,
        notes: { tournament_id: t.id, user_id: user.id },
      }),
    });
    const qr = await rz.json();
    if (!rz.ok) return json({ error: "payment gateway error", detail: qr }, 502);

    // Razorpay may adjust close_by: trust what it returns
    const expiresAt = new Date((qr.close_by ?? Math.floor(Date.now() / 1000) + QR_LIFETIME_SECONDS) * 1000).toISOString();

    const { error } = await admin.from("payments").insert({
      user_id: user.id,
      tournament_id: t.id,
      in_game_name,
      in_game_uid: in_game_uid ?? null,
      gateway_order_id: qr.id,
      amount: t.entry_fee,
      expires_at: expiresAt,
      qr_image_url: qr.image_url,
    });
    if (error) return json({ error: error.message }, 500);

    return json({ qr_id: qr.id, image_url: qr.image_url, amount: Number(t.entry_fee), expires_at: expiresAt, title: t.title });
  } catch (e) {
    return json({ error: String(e) }, 500);
  }
});
