# WarRoom Esports

Esports tournament app (Android APK via Capacitor) + Supabase backend + landing page.

```
warroom/
  app/          React + Vite app, wrapped as Android APK with Capacitor
  supabase/     database schema (migrations) + 2 edge functions (payments)
  landing/      index.html  (host anywhere, free: Netlify / Cloudflare Pages / GitHub Pages)
  .github/      workflow that builds the APK for free
```

## How money works (no wallet, no coins)
- Player taps "Pay & get QR" and the app shows a **UPI QR valid for 5 minutes** (single-use, fixed amount). They scan it with any UPI app. Razorpay tells our webhook, and only then the player is registered. If the QR expires, they tap "Get a new QR".
- While a player has a live QR, their slot is held, so a tournament can't be oversold.
- Paid tournaments are **18+ only** (checked from date of birth, server side). Free tournaments are open to all.
- **Prizes are never automatic.** Admin verifies result → *proposes* prize → **OWNER approves** → you send the money yourself → you mark it *paid* with the UTR. The database itself blocks anyone except the owner from approving.

## Setup (about 30 minutes)

### 1. Supabase (free plan is enough to start)
1. supabase.com → New project.
2. SQL Editor → paste `supabase/migrations/0001_init.sql` → Run. Then paste `0002_qr_payments.sql` → Run.
3. Authentication → Providers → Email → turn **off** "Confirm email" (easier signup for players).
4. Open the app, register your own account, then in SQL Editor run (use your email):
   ```sql
   update public.profiles set role = 'owner'
   where id = (select id from auth.users where email = 'YOUR@EMAIL.COM');
   ```
   Helpers you trust can be made `'admin'` the same way (they can create tournaments, verify results and *propose* prizes, but cannot approve or pay).
5. Project Settings → API: copy **Project URL** and the **anon/publishable key**.

### 2. App config
```
cd app
cp .env.example .env     # paste the URL + key
npm install
npm run dev              # test in browser
```

### 3. Payments (Razorpay UPI QR)
1. Create a Razorpay account.
2. **Important:** the dynamic "UPI QR" API is an on-demand feature. Email/raise a request with Razorpay support to **activate UPI QR Codes** on your account (works in test mode too once enabled). Without this, `create-qr` returns an error.
3. Install the Supabase CLI, then:
   ```
   supabase link --project-ref YOUR-REF
   supabase secrets set RAZORPAY_KEY_ID=rzp_test_xxx RAZORPAY_KEY_SECRET=xxx RAZORPAY_WEBHOOK_SECRET=choose-a-long-random-string
   supabase functions deploy create-qr
   supabase functions deploy razorpay-webhook --no-verify-jwt
   ```
4. Razorpay Dashboard → Webhooks → add `https://YOUR-REF.supabase.co/functions/v1/razorpay-webhook`, same secret, event: **`qr_code.credited`**.
5. Test in Test Mode first. Live mode needs Razorpay KYC and approval for your business type.
6. The QR lifetime is 5 minutes (`QR_LIFETIME_SECONDS` in `supabase/functions/create-qr/index.ts`; Razorpay allows 2 minutes to 2 hours).

### 4. Build the APK (free, no Play Store)
1. Create a GitHub repo and push this whole folder to the `main` branch.
2. Repo → Settings → Secrets and variables → Actions → add `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`.
3. The *Build WarRoom APK* workflow runs automatically (Actions tab). When done, the APK is attached to a Release.
4. Permanent link for your website:
   `https://github.com/YOUR_USER/YOUR_REPO/releases/latest/download/warroom-esports.apk`
5. Paste it into `landing/index.html` → `const APK_URL = "..."`, then host the landing page.

Note: this is a debug-signed APK, fine for direct download. Android may show "Install unknown apps" / Play Protect prompts because it's outside the Play Store. Later, for the Play Store, you'll need a proper signed release build.

## Before real money: check these
- Under India's Promotion and Regulation of Online Gaming Act 2025, e-sports are allowed with registration fee + performance-based prize money, but the game must be **registered** as an e-sport and there must be no betting/wagering. Confirm with a gaming lawyer and the registration process for the games you host.
- Prize money may attract TDS / PAN requirements. Ask a CA.
- Keep the Terms (Profile → Terms) in sync with how you actually run things, and add a refund process for cancelled tournaments (refund from the Razorpay dashboard).
- Don't use game publishers' names or logos in your branding; the landing page already has a non-affiliation line.

## What was tested here
- Database schema + security rules: 24 automated checks passed (player can't self-register or become admin, room ID hidden until registered, only the owner can approve/pay prizes, leaderboard counts verified results only, a live QR holds a slot and an expired one doesn't).
- App builds (`npm run build`), screens render without errors, and the Capacitor Android project generates correctly.
- QR payment screen tested in a real browser against a mocked backend: QR shows, 5-minute countdown runs, auto-registers when the payment lands, shows "QR expired" and issues a new QR on request.
- **Not tested here:** the final Gradle APK build (runs on GitHub, Android SDK can't be downloaded in this sandbox), and real Razorpay QR payments (needs your keys and UPI QR activation). Expect to fix small things on the first real run.
